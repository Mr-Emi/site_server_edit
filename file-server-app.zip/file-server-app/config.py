import os
from dotenv import load_dotenv
from werkzeug.exceptions import BadRequest

load_dotenv()

class Config:
    # Basic
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-change-me')
    DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'
    
    # Server
    PORT = int(os.getenv('PORT', 5000))
    HOST = os.getenv('HOST', '127.0.0.1')
    
    # JWT
    JWT_SECRET_KEY = os.getenv('JWT_SECRET')
    JWT_ACCESS_TOKEN_EXPIRES = int(os.getenv('JWT_EXPIRES_IN', 3600))
    JWT_BLACKLIST_ENABLED = os.getenv('JWT_BLACKLIST_ENABLED', 'true').lower() == 'true'
    JWT_BLACKLIST_STORAGE = 'redis' if os.getenv('REDIS_URL') else 'db'  # Fallback to db if no Redis
    
    # MongoDB
    MONGO_URI = os.getenv('MONGO_URI', 'mongodb://localhost:27017/fileserver')
    
    # Files
    MAX_CONTENT_LENGTH = int(os.getenv('MAX_FILE_SIZE', 1048576000))
    UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', 'uploads')
    ALLOWED_EXTENSIONS = set(os.getenv('ALLOWED_EXTENSIONS', 'jpg,png,pdf,mp4,zip,txt,js').split(','))
    
    # Security
    CSRF_ENABLED = os.getenv('CSRF_ENABLED', 'true').lower() == 'true'
    RATE_LIMIT = os.getenv('RATE_LIMIT', '100 per 15 minutes')
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    SCAN_VIRUS_ENABLED = os.getenv('SCAN_VIRUS_ENABLED', 'false').lower() == 'true'
    CAPTCHA_ENABLED = os.getenv('CAPTCHA_ENABLED', 'false').lower() == 'true'
    
    # Redis
    REDIS_URL = os.getenv('REDIS_URL', None)
    
    @staticmethod
    def validate():
        if not Config.JWT_SECRET_KEY:
            raise BadRequest('JWT_SECRET required in .env')
        if not Config.MONGO_URI:
            raise BadRequest('MONGO_URI required in .env')
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)