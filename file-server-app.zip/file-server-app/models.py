from pymongo import MongoClient
from marshmallow import Schema, fields, validate, ValidationError
from datetime import datetime
import os
from dotenv import load_dotenv
import logging

load_dotenv()

logger = logging.getLogger(__name__)

# Подключение к MongoDB
try:
    client = MongoClient(os.getenv('MONGO_URI'))
    client.admin.command('ping')
    logger.info("MongoDB подключен успешно!")
except Exception as e:
    logger.error(f"Ошибка MongoDB: {e}")
    raise

db = client['fileserver']

# Схемы
class UserSchema(Schema):
    username = fields.Str(required=True, validate=validate.Length(min=3, max=50))
    email = fields.Email(required=True)
    password = fields.Str(required=True, validate=validate.Length(min=6, max=128))
    role = fields.Str(default='user', validate=validate.OneOf(['user', 'admin']))
    settings = fields.Dict(default={})

class FileSchema(Schema):
    filename = fields.Str(required=True, validate=validate.Length(max=255))
    originalName = fields.Str(required=True, validate=validate.Length(max=255))
    mimetype = fields.Str(required=True, validate=validate.Length(max=100))
    size = fields.Int(required=True, validate=validate.Range(min=1))
    type = fields.Str(required=True, validate=validate.OneOf(['image', 'document', 'video', 'archive', 'other']))
    folder = fields.Str(default='root', validate=validate.Length(max=255))  # Или ref на FolderId
    shared = fields.Bool(default=False)
    sharedWith = fields.List(fields.Str(), default=[])
    owner = fields.Str(required=True)  # UserId

class FolderSchema(Schema):
    name = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    parent = fields.Str(default=None)  # Parent folderId for nested
    owner = fields.Str(required=True)  # UserId
    sharedWith = fields.List(fields.Str(), default=[])

class LogSchema(Schema):
    user = fields.Str(required=True)
    action = fields.Str(required=True)  # upload, download, edit, etc.
    file = fields.Str()
    folder = fields.Str()
    ip = fields.Str(required=True)
    timestamp = fields.DateTime(default=datetime.utcnow)

user_schema = UserSchema()
file_schema = FileSchema()
folder_schema = FolderSchema()
log_schema = LogSchema()