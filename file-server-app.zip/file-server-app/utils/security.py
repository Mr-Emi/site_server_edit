import os
import subprocess
import logging
from datetime import timedelta
from flask_jwt_extended import get_jwt
from redis import Redis
from config import Config

logger = logging.getLogger(__name__)

redis_client = None
if Config.REDIS_URL:
    redis_client = Redis.from_url(Config.REDIS_URL)

def is_virus(file_stream):
    """Virus scan simulation (integrate ClamAV in prod)"""
    if Config.SCAN_VIRUS_ENABLED:
        # Симуляция: 1% chance virus
        import random
        if random.random() < 0.01:
            logger.warning("Virus detected in file")
            return True
        # Real: subprocess.run(['clamscan', '--stdin'], input=file_stream.read())
    return False

def jwt_blacklist_callback(jwt_header, jwt_payload):
    """Check if token in blacklist"""
    if not Config.JWT_BLACKLIST_ENABLED:
        return False
    jti = jwt_payload["jti"]
    if Config.JWT_BLACKLIST_STORAGE == 'redis' and redis_client:
        return redis_client.get(f"blacklist:{jti}") is not None
    # Fallback to db (slower)
    from models import db
    return db.jwt_blacklist.find_one({'jti': jti}) is not None

def blacklist_token():
    """Add current token to blacklist on logout"""
    if not Config.JWT_BLACKLIST_ENABLED:
        return
    jti = get_jwt()["jti"]
    exp = get_jwt()["exp"]
    now = datetime.utcnow()
    ttl = timedelta(seconds=exp - now.timestamp())
    if Config.JWT_BLACKLIST_STORAGE == 'redis' and redis_client:
        redis_client.setex(f"blacklist:{jti}", ttl, 1)
    else:
        from models import db
        db.jwt_blacklist.insert_one({'jti': jti, 'expires': exp})