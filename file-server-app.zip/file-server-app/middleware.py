from functools import wraps
from flask import request, jsonify, abort
from flask_jwt_extended import jwt_required, get_jwt_identity, verify_jwt_in_request
from flask_wtf.csrf import CSRFError
from werkzeug.utils import secure_filename
from bleach import clean  # Для XSS sanitization
import os
import traceback
from config import Config
from utils.security import is_virus  # Симуляция
from models import db, log_schema  # Для логов

logger = logging.getLogger(__name__)

def auth_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            verify_jwt_in_request()
            current_user_id = get_jwt_identity()
            user = db.users.find_one({'_id': current_user_id})
            if not user:
                logger.warning(f"Auth failed: user {current_user_id} not found")
                return jsonify({'error': 'Пользователь не найден.'}), 401
            request.user = user
            request.user_id = str(user['_id'])
            return f(*args, **kwargs)
        except Exception as e:
            logger.error(f"Auth error: {traceback.format_exc()}")
            return jsonify({'error': 'Неверный токен.'}), 401
    return decorated_function

def admin_required(f):
    @wraps(f)
    @auth_required
    def decorated_function(*args, **kwargs):
        if request.user.get('role') != 'admin':
            logger.warning(f"Admin access denied for user {request.user_id}")
            return jsonify({'error': 'Доступ только для админов.'}), 403
        return f(*args, **kwargs)
    return decorated_function

def csrf_protect(f):
    if not Config.CSRF_ENABLED:
        return f
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            csrf_token = request.headers.get('X-CSRF-Token') or request.form.get('csrf_token')
            if not csrf.validate_csrf(csrf_token):  # From flask_wtf
                abort(400, 'CSRF token invalid')
            return f(*args, **kwargs)
        except CSRFError:
            logger.warning("CSRF validation failed")
            return jsonify({'error': 'CSRF token invalid'}), 400
    return decorated_function

def validate_file_upload(file):
    if not file:
        return False, 'Файл не загружен.'

    # Size check
    if file.content_length and file.content_length > Config.MAX_CONTENT_LENGTH:
        return False, 'Файл слишком большой.'

    # Type check
    if file.mimetype not in ['image/jpeg', 'image/png', 'application/pdf', 'video/mp4', 'application/zip', 'text/plain', 'application/javascript']:
        return False, 'Недопустимый тип файла.'

    # Extension check
    ext = os.path.splitext(file.filename)[1].lower()
    if ext[1:] not in Config.ALLOWED_EXTENSIONS:
        return False, 'Недопустимое расширение.'

    # Traversal check
    filename = secure_filename(file.filename)
    if '..' in filename or filename.startswith('/'):
        return False, 'Небезопасный путь.'

    # Virus scan (if enabled)
    if Config.SCAN_VIRUS_ENABLED:
        if is_virus(file.stream):  # Симуляция
            return False, 'Файл содержит вирус.'

    # File type determination
    file_type = 'other'
    if file.mimetype.startswith('image/'):
        file_type = 'image'
    elif file.mimetype == 'application/pdf':
        file_type = 'document'
    elif file.mimetype == 'text/plain':
        file_type = 'document'
    elif file.mimetype.startswith('video/'):
        file_type = 'video'
    elif file.mimetype in ['application/zip', 'application/x-tar']:
        file_type = 'archive'
    elif file.mimetype == 'application/javascript':
        file_type = 'other'

    file.stream.seek(0)  # Reset stream after scan
    return True, file_type, filename

def sanitize_input(input_data):
    """XSS protection: Sanitize strings"""
    if isinstance(input_data, str):
        return clean(input_data, tags=[], strip=True)
    elif isinstance(input_data, dict):
        return {k: sanitize_input(v) for k, v in input_data.items()}
    elif isinstance(input_data, list):
        return [sanitize_input(item) for item in input_data]
    return input_data

def log_action(action, file_id=None, folder_id=None, ip=None):
    """Audit log"""
    if not ip:
        ip = request.remote_addr
    log_data = {
        'user': request.user_id if hasattr(request, 'user_id') else 'anonymous',
        'action': action,
        'file': str(file_id) if file_id else None,
        'folder': str(folder_id) if folder_id else None,
        'ip': ip,
        'timestamp': datetime.utcnow()
    }
    db.logs.insert_one(log_data)
    logger.info(f"Log: {action} by {log_data['user']} from {ip}")