from flask import Blueprint, request, jsonify, send_file
from models import db, file_schema
from middleware import auth_required, admin_required, validate_file_upload
from marshmallow import ValidationError
from werkzeug.utils import secure_filename
import os
from datetime import datetime

files_bp = Blueprint('files', __name__)

@files_bp.route('/upload', methods=['POST'])
@auth_required
def upload():
    if 'file' not in request.files:
        return jsonify({'error': 'Файл не загружен.'}), 400

    file = request.files['file']
    valid, result = validate_file_upload(file)
    if not valid:
        return jsonify({'error': result}), 400

    file_type, filename = result
    full_path = os.path.join('uploads', filename)
    file.save(full_path)

    file_data = {
        'filename': filename,
        'path': full_path,
        'originalName': secure_filename(request.files['file'].filename),
        'mimetype': file.mimetype,
        'size': file.content_length,
        'owner': str(request.user['_id']),
        'type': file_type,
        'folder': request.form.get('folder', 'root'),
        'shared': False,
        'sharedWith': [],
        'created_at': datetime.now()
    }

    try:
        file_id = db.files.insert_one(file_data).inserted_id
        file_data['_id'] = str(file_id)
        return jsonify(file_data)
    except Exception as e:
        os.remove(full_path)  # Cleanup
        return jsonify({'error': 'Ошибка загрузки.'}), 500

@files_bp.route('/', methods=['GET'])
@auth_required
def get_files():
    page = int(request.args.get('page', 1))
    limit = int(request.args.get('limit', 10))
    file_type = request.args.get('type')
    search = request.args.get('search')
    folder = request.args.get('folder', 'root')

    query = {'owner': str(request.user['_id']), 'folder': folder}
    if file_type:
        query['type'] = file_type
    if search:
        query['originalName'] = {'$regex': search, '$options': 'i'}

    files = list(db.files.find(query).sort('created_at', -1).skip((page-1)*limit).limit(limit))
    total = db.files.count_documents(query)
    pages = (total + limit - 1) // limit

    for f in files:
        f['_id'] = str(f['_id'])
        f['owner'] = str(f['owner'])

    return jsonify({'files': files, 'total': total, 'pages': pages})

@files_bp.route('/<file_id>/download', methods=['GET'])
@auth_required
def download(file_id):
    file_doc = db.files.find_one({'_id': file_id, 'owner': str(request.user['_id'])})
    if not file_doc:
        return jsonify({'error': 'Файл не найден.'}), 404

    return send_file(file_doc['path'], as_attachment=True, download_name=file_doc['originalName'])

@files_bp.route('/<file_id>', methods=['DELETE'])
@auth_required
def delete_file(file_id):
    file_doc = db.files.find_one({'_id': file_id, 'owner': str(request.user['_id'])})
    if not file_doc:
        return jsonify({'error': 'Файл не найден.'}), 404

    db.files.delete_one({'_id': file_id})
    os.remove(file_doc['path'])
    return jsonify({'message': 'Файл удален.'})

@files_bp.route('/<file_id>/share', methods=['PUT'])
@auth_required
def share_file(file_id):
    file_doc = db.files.find_one({'_id': file_id})
    if not file_doc or file_doc['owner'] != str(request.user['_id']):
        return jsonify({'error': 'Нет доступа.'}), 403

    shared_with = request.json.get('sharedWith', [])
    db.files.update_one({'_id': file_id}, {'$set': {'shared': True, 'sharedWith': shared_with}})
    updated = db.files.find_one({'_id': file_id})
    updated['_id'] = str(updated['_id'])
    return jsonify(updated)

@files_bp.route('/stats', methods=['GET'])
@auth_required
def stats():
    owner_id = str(request.user['_id'])
    total_files = db.files.count_documents({'owner': owner_id})
    total_size = db.files.aggregate([{'$match': {'owner': owner_id}}, {'$group': {'_id': None, 'total': {'$sum': '$size'}}}])
    total_size = list(total_size)[0]['total'] if list(total_size) else 0

    by_type = list(db.files.aggregate([
        {'$match': {'owner': owner_id}},
        {'$group': {'_id': '$type', 'count': {'$sum': 1}, 'size': {'$sum': '$size'}}}
    ]))

    return jsonify({'totalFiles': total_files, 'totalSize': total_size, 'byType': by_type})

@files_bp.route('/admin/logs', methods=['GET'])
@admin_required
def admin_logs():
    # Симуляция логов; в реальности — из отдельной коллекции db.logs
    mock_logs = [
        {'user': 'user_alpha', 'action': 'Загрузка', 'file': 'report.pdf', 'time': '2 минуты назад'},
        {'user': 'user_beta', 'action': 'Скачивание', 'file': 'project.zip', 'time': '5 минут назад'},
        # Добавьте больше
    ]
    return jsonify(mock_logs)

@files_bp.route('/admin/action', methods=['POST'])
@admin_required
def admin_action():
    action = request.json.get('action')
    if action == 'backup':
        # Симуляция; в реальности — subprocess.call('backup.sh')
        return jsonify({'message': 'Резервная копия создана.'})
    return jsonify({'error': 'Неизвестное действие.'}), 400