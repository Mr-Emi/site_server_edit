from flask import Blueprint, jsonify, request
from flask_jwt_extended import create_access_token, jwt_required, get_jwt
from models import db, user_schema
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import timedelta
import logging
from utils.security import blacklist_token

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    errors = user_schema.validate(data)
    if errors:
        return jsonify({'error': errors}), 400
    
    if db.users.find_one({'email': data['email']}):
        return jsonify({'error': 'Email already exists'}), 400

    hashed_pw = generate_password_hash(data['password'])
    user = {
        'username': data['username'],
        'email': data['email'],
        'password': hashed_pw,
        'role': 'user',
        'created_at': datetime.utcnow()
    }
    db.users.insert_one(user)
    return jsonify({'message': 'User created'}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = db.users.find_one({'email': data['email']})
    if not user or not check_password_hash(user['password'], data['password']):
        return jsonify({'error': 'Invalid credentials'}), 401
    
    expires = timedelta(minutes=45) if request.headers.get('Remember-Me') else timedelta(hours=1)
    access_token = create_access_token(identity=str(user['_id']), expires_delta=expires)
    
    return jsonify({
        'token': access_token,
        'user': {
            'id': str(user['_id']),
            'email': user['email'],
            'role': user['role']
        }
    }), 200

@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    blacklist_token()
    return jsonify({'message': 'Successfully logged out'}), 200