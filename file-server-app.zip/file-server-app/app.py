from flask import Flask, render_template, send_from_directory, jsonify, request
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman
from flask_wtf.csrf import CSRFProtect
from dotenv import load_dotenv
import os
import logging
import traceback
from config import Config
from werkzeug.middleware.proxy_fix import ProxyFix

# Изменить секцию JWT


load_dotenv()
app = Flask(__name__)
app.config.from_object(Config)
Config.validate()   

# Logging (полноценный)
logging.basicConfig(
    level=getattr(logging, app.config['LOG_LEVEL']),
    format='%(asctime)s %(levelname)s %(message)s',
    handlers=[logging.StreamHandler(), logging.FileHandler('app.log')]
)
app.logger = logging.getLogger(__name__)

# JWT
jwt = JWTManager(app)
jwt.token_in_blocklist_loader(jwt_blacklist_callback)

# CORS (strict для prod)
CORS(app, resources={
    r"/api/*": {
        "origins": "*",  # Dev; prod: ["https://yourdomain.com"]
        "methods": ["GET", "POST", "PUT", "DELETE"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})

# Limiter (исправлено)
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=[app.config['RATE_LIMIT']]
)

# Talisman (усиленная защита: CSP, HSTS)
csp = {
    'default-src': "'self'",
    'script-src': "'self' 'unsafe-inline' https://cdnjs.cloudflare.com",
    'style-src': "'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com",
    'img-src': "'self' data: https:",
    'font-src': "'self' https://fonts.gstatic.com",
    'frame-src': "'self' https://yourdomain.com"  # Для iframe просмотра
}
Talisman(app, force_https=False, content_security_policy=csp)  # Prod: force_https=True

# CSRF (если enabled)
if app.config['CSRF_ENABLED']:
    csrf = CSRFProtect(app)
    app.logger.info("CSRF protection enabled")

# Импорты после config (чтобы db инициализировалась)
from models import client, db  # db теперь глобальная
from routes.auth import auth_bp
from routes.files import files_bp
from routes.folders import folders_bp  # Новый
from utils.security import jwt_blacklist_callback, check_virus  # Новые

# JWT blacklist callback (если enabled)
if app.config['JWT_BLACKLIST_ENABLED']:
    from flask_jwt_extended import JWTManager
    jwt.token_in_blacklist_loader(jwt_blacklist_callback)

# Blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(files_bp, url_prefix='/api/files')
app.register_blueprint(folders_bp, url_prefix='/api/folders')

# Frontend
@app.route('/')
def index():
    if app.config['CSRF_ENABLED']:
        return render_template('index.html', csrf_token=csrf.generate_csrf())
    return render_template('index.html')

@app.route('/uploads/<filename>')
@limiter.limit("10 per minute")  # Защита от brute download
def uploaded_file(filename):
    from werkzeug.utils import secure_filename
    if not os.path.basename(filename) == secure_filename(filename):  # Anti-traversal
        return jsonify({'error': 'Invalid path'}), 400
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# Health check
@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'db': 'connected' if client else 'error'})

# Глобальная обработка ошибок (JSON always)
@app.errorhandler(Exception)
def handle_error(error):
    app.logger.error(f"Global error: {traceback.format_exc()}")
    return jsonify({'error': 'Internal server error'}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(413)  # File too large
def too_large(error):
    return jsonify({'error': 'File too large'}), 413

# Cleanup
@app.teardown_appcontext
def close_db(exception):
    if 'client' in globals():
        client.close()

app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

if __name__ == '__main__':
    app.run(debug=app.config['DEBUG'], host=app.config['HOST'], port=app.config['PORT'])
    app.logger.info(f"Server started on {app.config['HOST']}:{app.config['PORT']}")